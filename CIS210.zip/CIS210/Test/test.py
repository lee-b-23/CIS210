print("Hello, world!")
x = 12
print(x+14)
