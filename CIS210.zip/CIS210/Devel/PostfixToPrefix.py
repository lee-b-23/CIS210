'''
The plan:
 - put all characters into a stack
'''
