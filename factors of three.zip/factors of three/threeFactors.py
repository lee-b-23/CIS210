"""
This program's purpose is to find all of the factors of three in an array.

Author: Lee Brown
Name: threeFactors.py
Details:
"""
import randomIntList as r
"""
pre-dev outline:
 - takes input of an array
 - uses conditions to judge potential factors:
    - is 3-number 0
    - is 3-number 2
 - if condition is met, a counter will be incremented to say how many factors
   there were, and the factor will be added to an array.

method(inputArray):
    for length of array:
        if is a factor
            factorCount = factorCount+1
            newArray = newArray.append(factor)
    return or print factor count
"""

def threeFactors(array):
    factorsCounter = 0
    resultsArray = []
    for x in range(0, len(array)-1):
        if((3 - array[x]) == 2 or (3- array[x]) == 0 or (3- array[x]) == 6 or (3- array[x]) == 4):
            factorsCounter = factorsCounter + 1
            resultsArray.append(array[x])
    return(resultsArray)

def test():
    array = r.randomIntList(10000, -10, 10)
    #print(array)
    print("")
    totalFactors = threeFactors(array)
    print("factors of three")
    print(totalFactors)
test()
